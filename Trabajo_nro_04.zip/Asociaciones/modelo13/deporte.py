class Deporte():

    def __init__(self, duracion_partida, nro_jugadores, nombre, pelota, puntos_necesitados):
        self.duracion_partida = duracion_partida
        self.nro_jugadores = nro_jugadores
        self.nombre = nombre
        self.pelota = pelota
        self.puntos_necesitados = puntos_necesitados

    def recrear(self):
        return "recreando"

    def ejercitar(self):
        return "ejercitando"

    def motivar(self):
        return "motivando"
