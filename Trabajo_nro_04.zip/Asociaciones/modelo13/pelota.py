class Pelota():

    def __init__(self, volumen, color, peso, material, duracion):
        self.volumen = volumen
        self.color = color
        self.peso = peso
        self.material = material
        self.duracion = duracion

    def jugar(self):
        return "jugando"

    def pegar(self):
        return "pegando"

    def lanzar(self):
        return "lanzar"
