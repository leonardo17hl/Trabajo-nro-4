class Computadora():

    def __init__(self,procesador, velocidad_procesador, ram, material, marca):
        self.procesador = procesador
        self.velocidad_procesador = velocidad_procesador
        self.ram = ram
        self.material = material
        self.marca = marca

    def almacenar(self):
        return "almacenando"

    def reproducir(self):
        return "reproduciendo"

    def controlar(self):
        return "controlando"
