class Escritorio():

    def __init__(self, material, procedencia, peso_carga, peso, computadora):
        self.material = material
        self.procedencia = procedencia
        self.peso_carga = peso_carga
        self.peso = peso
        self.computadora = computadora

    def organizar_cosas(self):
        return "organizando cosas"

    def hacer_tareas(self):
        return "realizando tareas sobre el escritorio"

    def estudiar(self):
        return "estudiando en el escritorio"
