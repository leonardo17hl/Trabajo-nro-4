class Lapiz():

    def __init__(self, material ,precio , largo, ubicacion, grosor):
        self.material= material
        self.precio = precio
        self.largo = largo
        self.ubicacion = ubicacion
        self.grosor = grosor

    def manchar(self):
        return "manchando"

    def rallar(self):
        return "rallar"

    def incar(self):
        return "incando"

