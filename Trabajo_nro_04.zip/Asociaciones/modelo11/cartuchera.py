class Cartuchera():

    def __init__(self, estilo_cierre, material, precio, nro_cierres, color):
        self.estilo_cierre = estilo_cierre
        self.material = material
        self.precio = precio
        self.nro_cierres = nro_cierres
        self.color = color

    def guardar_utiles(self):
        return "guardando utiles"

    def proteger_utiles(self):
        return "protegiendo utiles"

    def organizar_utiles(self):
        return "organizando utiles"
