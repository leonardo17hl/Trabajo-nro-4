class Tomacorriente():

    def __init__(self, tension_nominal, corriente_nominal, disenio, material, procedencia):
        self.tension_nominal = tension_nominal
        self.corrinte_nominal = corriente_nominal
        self.disenio = disenio
        self.material = material
        self.procedencia = procedencia

    def estabilizar_corriente(self):
        return "estabilizando corriente"

    def enchufar(self):
        return "enchufando"

    def desconectar(self):
        return "desconectando"
