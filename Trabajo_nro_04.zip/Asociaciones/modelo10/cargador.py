class Cargador():

    def __init__(self, tension_salida, amperaje, procedencia, voltaje, resistencia):
        self.tension_salida = tension_salida
        self.amperaje = amperaje
        self.procedencia = procedencia
        self.voltaje = voltaje
        self.resistencia = resistencia

    def cargar(self):
        return "cargando dispositivo"

    def conectar(self):
        return "conectando"

    def encender(self):
        return "encendiendo"

