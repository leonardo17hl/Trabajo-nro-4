class Profesor():

    def __init__(self, dni, centro_educativo, nivel, nombre, sueldo):
        self.dni = dni
        self.centro_educativo = centro_educativo
        self.nivel = nivel
        self.nombre = nombre
        self.sueldo = sueldo

    #enseñar() motivar() educar()
    def enseñar(self):
        return "enseñando"

    def motivar(self):
        return "motivando"

    def educar(self):
        return "educando"

