class Alumno():

    def __init__(self, edad, nro_cursos_otorgados, profesor, centro_educativo, grado_educativo):
        self.edad = edad
        self.nro_cursos_otorgados = nro_cursos_otorgados
        self.profesor = profesor
        self.centro_educativo = centro_educativo
        self.grado_educativo = grado_educativo

    #apreder() asistir() leer()
    def aprender(self):
        return "aprendiendo"

    def asistir(self):
        return "asistiendo"

    def leer(self):
        return "leendo"
