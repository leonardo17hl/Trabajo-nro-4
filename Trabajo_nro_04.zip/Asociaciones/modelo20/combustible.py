class combustible():

    def __init__(self, olor, espesor, composicion, precio_galon, empresa_procedencia):
        self.olor = olor
        self.espesor = espesor
        self.composicion = composicion
        self.precio_galon = precio_galon
        self.empresa_procedencia = empresa_procedencia

    def quemar(self):
        return "quemando"

    def contaminar(self):
        return "contaminando"

    def dar_funcion_al_motor(self):
        return "dando funcion al motor"
