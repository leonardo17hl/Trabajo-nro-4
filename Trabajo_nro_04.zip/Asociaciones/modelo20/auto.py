class Auto():

    def __init__(self, nro_placa, marca, nro_asientos, alimentacion, tipo):
        self.nro_placa = nro_placa
        self.marca = marca
        self.nro_asinentos = nro_asientos
        self.alimentacion = alimentacion
        self.tipo = tipo

    def acelera(self):
        return "acelerando"

    def desacelerar(self):
        return "desacelerando"

    def llevar_pasajeros(self):
        return "llevando pasajeros"
