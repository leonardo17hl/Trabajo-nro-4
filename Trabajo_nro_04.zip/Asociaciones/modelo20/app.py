import auto
import combustible
import os
