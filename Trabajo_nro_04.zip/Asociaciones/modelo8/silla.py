class Silla():

    def __init__(self, numero_patas, mesa, color, marca):
        self.numero_patas = numero_patas
        self.mesa = mesa
        self.color = color
        self.marca = marca

    #soportar_peso() apilar() decorar()
    def soportar_peso(self):
        return "soportando peso de objeto"

    def apilar(self):
        return "apilar"

    def decorar(self):
        return "decorar"
