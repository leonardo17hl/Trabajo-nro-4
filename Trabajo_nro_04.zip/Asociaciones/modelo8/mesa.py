class Mesa():

    def __init__(self, numero_patas, material, peso, forma, pais_elaboracion):
        self.numero_patas = numero_patas
        self.material = material
        self.peso = peso
        self.forma = forma
        self.pais_elaboracion = pais_elaboracion

    # soportar_peso() servir_comida() decorar()
    def soportar_peso(self):
        return "soportando peso de objetos"

    def servir_comida(self):
        return "ubicando la comida sobre la mesa"

    def decorando(self):
        return "decorando"
