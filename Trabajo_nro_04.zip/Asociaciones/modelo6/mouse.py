class Mouse():

    def __init__(self, compatibilidad, tipo_sensor_optico, aceleracion, resolucion, laptop):
        self.compatibilidad = compatibilidad
        self.tipo_sensor_optico = tipo_sensor_optico
        self.aceleracion = aceleracion
        self.resolucion = resolucion
        self.laptop = laptop

    # direccionar() jugar() manejar()
    def direccionar(self):
        return "direccionando"

    def jugar(self):
        return "jugando"

    def manejar(self):
        return "manejando"
