class Laptop():

    def __init__(self, velocidad_procesador, tipo_disco_duro, tipo_tarjeta_video, duracion_bateria, tipo_procesador):
        self.velocidad_procesador = velocidad_procesador
        self.tipo_disco_duro = tipo_disco_duro
        self.tipo_tarjeta_video = tipo_tarjeta_video
        self.duracion_bateria = duracion_bateria
        self.tipo_procesador = tipo_procesador

    # almacenar() reproducir() controlar()
    def almacenar(self):
        return "almacenando"

    def reproducir(self):
        return "reproduciendo"

    def conrolar(self):
        return "controlando"
