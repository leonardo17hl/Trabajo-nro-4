class Cancion():

    def __init__(self, idioma, duracion, compositor, interprete, album):
        self.idioma = idioma
        self.duracion = duracion
        self.compositor = compositor
        self.interprete = interprete
        self.album = album

    # inspirar() emocionar() incitar_baile()
    def inspirar(self):
        return "inspirando"

    def emocionar(self):
        return "emocionando"

    def incitar_baile(self):
        return "por iniciar baile"
