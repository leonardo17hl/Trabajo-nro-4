class Interprete():

    def __init__(self, nombre, edad, dni, discografia, creacion):
        self.nombre = nombre
        self.edad = edad
        self.dni = dni
        self.discografia = discografia
        self.creacion =""
