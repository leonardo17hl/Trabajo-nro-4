class Chancho():

    def __init__(self, peso, edad, ubicacion, raza, nro_crias):
        self.peso = peso
        self.edad = edad
        self.ubicacion = ubicacion
        self.raza = raza
        self.nro_crias = nro_crias

    def comer(self):
        return "comiendo"

    def dormir(self):
        return "durmiendo"

    def caminar(self):
        return "caminando"
