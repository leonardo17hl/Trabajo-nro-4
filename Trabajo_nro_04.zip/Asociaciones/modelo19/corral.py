class Corral():

    def __init__(self, ancho, largo, nro_animales, material, ubicacion):
        self.ancho = ancho
        self.largo = largo
        self.nro_animales = nro_animales
        self.material = material
        self.ubicacion = ubicacion

    def proteger_animales(self):
        return "protegiendo animales"

    def ordenar_ambiente(self):
        return "ordenando ambiente"

    def ocupar_territorio(self):
        return "ocupando territorio"
