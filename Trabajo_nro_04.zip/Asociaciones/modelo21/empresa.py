class Empresa():

    def __init__(self, anio_fundacion, duenio, tipo_empresa, ambito, nro_trabajadores):
        self.anio_fundacion = anio_fundacion
        self.duenio = duenio
        self.tipo_empresa = tipo_empresa
        self.ambito = ambito
        self.nro_trabajadores = nro_trabajadores

    def ofrecer_servicios(self):
        return "ofreciendo servicios"

    def pagar_impuestos(self):
        return "pagando impuestos"

    def satisfacer_clientes(self):
        return "satisfaciendo a sus clientes"
