class Trabajador():

    def __init__(self, empresa_trabajo, nombre, anios_experiencia, horas_trabajo_dia, dni):
        self.empresa_trabajo = empresa_trabajo
        self.nombre = nombre
        self.anios_experiencia = anios_experiencia
        self.horas_trabajo_dia = horas_trabajo_dia
        self.dni = dni

    def trabajr(self):
        return "trabajando"

    def ganar_dindero(self):
        return "obteniendo ingresos"

    def ganar_experiencia(self):
        return "ganando experiencia"
