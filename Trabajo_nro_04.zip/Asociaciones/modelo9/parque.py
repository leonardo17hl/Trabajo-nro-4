class Parque():

    def __init__(self, ubicacion, area_vegetacion, area_recreacion, anio_construccion, nro_bancas):
        self.ubicacion = ubicacion
        self.area_vegetacion = area_vegetacion
        self.area_recreacion = area_recreacion
        self.anio_construccion = anio_construccion
        self.nro_bancas = nro_bancas

    #recrear() pasear_mascota() decorar()
    def recrear(self):
        return "recreando"

    def pasear_mascota(self):
        return "paseando mascotas en el parque"

    def decorar(self):
        return "decorando la ciudad"
