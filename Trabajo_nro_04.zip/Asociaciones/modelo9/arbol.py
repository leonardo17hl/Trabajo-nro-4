class Arbol():

    def __init__(self, familia, parque, clase, orden, nombre_cientifico):
        self.familia = familia
        self.parque = parque
        self.clase = clase
        self.orden = orden
        self.nombre_cientifico = nombre_cientifico

    #purificar() decorar() conservar_especie()
    def purificar(self):
        return "purificando el aire"

    def decorar(self):
        return "decorando el parque"

    def conservando_especie(self):
        return "manteniendo especie de arboles"
