class Piloto():

    def __init__(self, nombre, edad, anios_experiencia, nacionalidad, centro_formacion):
        self.nombre = nombre
        self.edad = edad
        self.anios_experiencia = anios_experiencia
        self.nacionalidad = nacionalidad
        self.centro_formacion = centro_formacion

    def manejar(self):
        return "manejando"

    def viajar(self):
        return "viajando"

    def reportar_viaje(self):
        return "reportando_viaje"
