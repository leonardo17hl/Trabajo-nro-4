class Avion():

    def __init__(self, motor, procedencia, material_estructura, anio_construccion, piloto):
        self.motor = motor
        self.procedencia = procedencia
        self.material_estructura = material_estructura
        self.anio_construccion = anio_construccion
        self.piloto = piloto

    def llevar_pasajeros(self):
        return "llevando pasajeros"

    def aterrizar(self):
        return "aterrizando"

    def despegar(self):
        return "despegando"
