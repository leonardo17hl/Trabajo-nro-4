class Departamento():

    def __init__(self, nro_provincias, pais, nro_habitantes, nombre, nro_distritos):
        self.nro_provincias = nro_provincias
        self.pais = pais
        self.nro_habitantes = nro_habitantes
        self.nombre = nombre
        self.nro_distritos = nro_distritos

    def ordenar(self):
        return "ordenando"

    def organizar(self):
        return "organizando"

    def proteger_poblacion(self):
        return "protegiendo a sus pobladores"
