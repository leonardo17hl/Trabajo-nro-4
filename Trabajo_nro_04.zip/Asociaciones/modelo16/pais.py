class Pais():

    def __init__(self, presidente, moneda, capital, poblacion, area):
        self.presidente = presidente
        self.moneda = moneda
        self.capital = capital
        self.poblacion = poblacion
        self.area = area

    def ordenar(self):
        return "ordenando"

    def organizar(self):
        return "organizando"

    def proteger_poblacion(self):
        return "protegiendo a sus pobladores"
