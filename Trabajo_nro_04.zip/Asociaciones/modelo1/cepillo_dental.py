class Cepillo_dental():

    def __init__(self, material, dentifrico, marca1, procedencia, peso):
        self.material = material
        self.dentifrico = dentifrico
        self.marca1 = marca1
        self.procedencia = procedencia
        self.peso = peso

    def limpiar(self):
        return "El cepillo dental " +self.marca1 + " tiene dentifrico " + self.dentifrico.getMarca()

    def getDentifrico(self):
        return  self.dentifrico

    def setDentifrico(self, dentifrico):
        self.dentifrico = dentifrico

    def remover(self):
        return "removiendo"

    def asear(self):
        return "aseando"

    def getMarca1(self):
        return self.marca1

    def setMarca1(self,marca):
        self.marca1=marca1
