import dentifrico
import cepillo_dental
import os

marca_dentifrico1 = os.sys.argv[1]
marca_cepillo = os.sys.argv[2]
marca_dentifrico2 = os.sys.argv[3]

d1 = dentifrico.Dentifrico("carton", 500, marca_dentifrico1, 550, "Lima")
c1 = cepillo_dental.Cepillo_dental("madera",d1,marca_cepillo,"Trujillo",40)

print("Cepillo dental : " + c1.getMarca1())
c1.setMarca1("listerine")
c1.setDentifrico(marca_dentifrico2)
print(c1.limpiar())
