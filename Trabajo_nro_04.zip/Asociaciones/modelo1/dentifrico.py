class Dentifrico():

    def __init__(self, material_envase, contenido_fluor, marca, contenido_neto, procedencia):
        self.material_envase = material_envase
        self.contenido_fluor = contenido_fluor
        self.marca = marca
        self.contenido_neto = contenido_neto
        self.procedencia = procedencia

    def blanquear(self):
        return "blanqueando"

    def limpiar(self):
        return "limpiando"

    def aromatizar(self):
        return "aromatizando"

    def getMarca(self):
        return self.marca
#fin_class
