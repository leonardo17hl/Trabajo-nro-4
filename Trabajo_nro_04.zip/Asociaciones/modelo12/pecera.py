class Pecera():

    def __init__(self, forma, capacidad, material, nro_peces, anios_garantia):
        self.forma = forma
        self.capacidad = capacidad
        self.material = material
        self.nro_peces = nro_peces
        self.anios_garantia = anios_garantia

    def proteger_peces(self):
        return "protegiendo peces"

    def decorar_casa(self):
        return "decorando casa"

    def contener_agua(self):
        return "conteniendo agua"
