class Pez():

    def __init__(self, nombre_comun, nombre_cientifico, familia, anios_vida, ambiente):
        self.nombre_comun = nombre_comun
        self.nombre_cientifico = nombre_cientifico
        self.familia = familia
        self.anios_vida = anios_vida
        self.ambiente = ambiente

    def nadar(self):
        return " nadando"

    def comer(self):
        return "comiendo"

    def perpetuar_especie(self):
        return "perpetuando especie"
