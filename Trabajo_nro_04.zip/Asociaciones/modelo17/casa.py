class Casa():

    def __init__(self, propietario, direccion, valorizacion_soles, nro_banios, material_construccion):
        self.propietario = propietario
        self.direccion = direccion
        self.valorizacion_soles = valorizacion_soles
        self.nro_banios = nro_banios
        self.material_construccion = material_construccion

    def albergar(self):
        return "albergando"

    def ocupar_espacio(self):
        return "ocupando espacio"

    def unir_familia(self):
        return "conviviendo en familia"
