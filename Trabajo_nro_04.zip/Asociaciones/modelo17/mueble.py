class Mueble():

    def __init__(self, color, material, procedencia, nro_patas, ubicacion):
        self.color = color
        self.material = material
        self.procedencia = procedencia
        self.nro_patas = nro_patas
        self.ubicacion = ubicacion

    def sostener(self):
        return "sosteniendo"

    def decorar(self):
        return "decorando"

    def ocupar_espacio(self):
        return "ocupando espacio"
