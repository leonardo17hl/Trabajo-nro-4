class Control_remoto():

    def __init__(self, marca, televisor, numero_teclas, idiomas_compatibles, duracion_bateria):
        self.marca = marca
        self.televisor = televisor
        self.numero_teclas = numero_teclas
        self.idiomas_compatibles = idiomas_compatibles
        self.duracion_bateria = duracion_bateria

    def encender(self):
        return self.marca + " esta encendiendo al televisor de procesador " + self.televisor.getProcesador()

    def controlar(self):
        return "esta controlando"

    def apagar(self):
        return "esta apagando"

    def getTelevisor(self):
        return self.televisor

    def setTelevisor(self, televisor):
        self.televisor = televisor
