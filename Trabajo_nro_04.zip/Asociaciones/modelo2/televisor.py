class Televisor():

    def __init__(self, procedencia, tamanio_pantalla, tecnologia, procesador, tipo_pantalla):
        self.procedencia = procedencia
        self.tamanio_pantalla = tamanio_pantalla
        self.tecnologia = tecnologia
        self.procesador = procesador
        self.tipo_pantalla = tipo_pantalla

        # receptar_canales() reproducir() transmitir()
    def receptar_canales(self):
        return "esta recepcionando canales"

    def reproducir(self):
        return "esta reproduciendo"

    def transmitir(self):
        return  " esta transmitiendo"

    def getProcesador(self):
        return self.procesador
