import televisor
import control_remoto
import os

proc = os.sys.argv[1]
marc = os.sys.argv[2]

t1 = televisor.Televisor("lima",15,"core",proc,"circular")
c1 = control_remoto.Control_remoto(marc,t1,20,5,100)

