class Libro():

    def __init__(self, editorial, escritor, nro_paginas, anio_publicacion, biblioteca):
        self.editorial = editorial
        self.escritor = escritor
        self.nro_paginas = nro_paginas
        self.anio_publicacion = anio_publicacion
        self.biblioteca = biblioteca

    # culturizar() aprender() emocionar()
    def culturizar(self):
        return "culturulizando"

    def aprender(self):
        return "aprendiendo"

    def emocionar(self):
        return "emocionando"
