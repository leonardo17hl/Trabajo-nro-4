class Biblioteca():

    def __init__(self, direccion, anio_construccion, nro_carpetas, nro_libros, nro_sillas):
        self.direccion = direccion
        self.anio_construccion = anio_construccion
        self.nro_carpetas = nro_carpetas
        self.nro_libros = nro_libros
        self.nro_sillas = nro_sillas

    def guardar_libros(self):
        return "guardando libros"

    def prestar_libros(self):
        return "prestando libros"

    def exhibir_libros(self):
        return "exhibiendo libros"
