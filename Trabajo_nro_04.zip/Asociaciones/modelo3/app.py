import escritor
import libro
import os
