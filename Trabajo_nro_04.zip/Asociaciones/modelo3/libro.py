class Libro():

    def __init__(self, editorial, escritor, nro_paginas, anio_publicacion, material):
        self.editorial = editorial
        self.escritor = escritor
        self.nro_paginas = nro_paginas
        self.anio_publicacion = anio_publicacion
        self.material = material

    # culturizar() aprender() emocionar()
    def culturizar(self):
        return "culturulizando"

    def aprender(self):
        return "aprendiendo"

    def emocionar(self):
        return "emocionando"
