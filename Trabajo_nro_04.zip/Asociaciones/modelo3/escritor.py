class Escritor():

    def __init__(self, nombre, edad, estado_civil, dni, domicilio):
        self.nombre = nombre
        self.edad = edad
        self.estado_civil = estado_civil
        self.dni = dni
        self.domicilio = domicilio

    # escribir() leer() viajar()
    def escribir(self):
        return "escribiendo"

    def leer(self):
        return "leendo"

    def viajar(self):
        return "viajando"
