class Estadio():

    def __init__(self, area, capacidad, nombre, ubicacion, anio_edificacion):
        self.area = area
        self.capacidad = capacidad
        self.nombre = nombre
        self.ubicacion = ubicacion
        self.anio_edificacion = anio_edificacion

    # presentar_artistas()  presentar_deporte() producir_eventos()
    def presentar_artistas(self):
        return "inicinado presentacion de artistas"

    def presentar_deporte(self):
        return "exibiendo un deporte"

    def producir_eventos(self):
        return "realizandose un evento"
