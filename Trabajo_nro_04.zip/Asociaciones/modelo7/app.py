import atleta
import estadio
import os
