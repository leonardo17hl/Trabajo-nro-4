class Atleta():

    def __init__(self, nro_medallas, anios_activo, edad, nombre, velocidad):
        self.nro_medallas = nro_medallas
        self.anios_activo = anios_activo
        self.edad = edad
        self.nombre = nombre
        self.velocidad = velocidad

    # ganar_medallas() correr() viajar()
    def ganar(self):
        return "esforsandose para ganar"

    def correr(self):
        return "corriendo"

    def viajar(self):
        return "viajando"
